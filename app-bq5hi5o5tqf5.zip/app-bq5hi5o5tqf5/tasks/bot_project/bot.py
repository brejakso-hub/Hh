#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ربات بازی خطکش روبیکا
Ruler Game Bot for Rubika Messenger
made by @hajibehnad
"""

import os
import sys
import json
import random
import string
import sqlite3
import datetime
import threading
from pathlib import Path

# اضافه کردن مسیر کتابخانه rubka
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'rubka-main'))

from rubka import Robot
from rubka.context import Message
from rubka.keypad import ChatKeypadBuilder

# ─── تنظیمات ───
DB_PATH = os.path.join(os.path.dirname(__file__), "ruler_game.db")
ADMIN_SECRET = "githd"
DEFAULT_MIN_GROW = 1
DEFAULT_MAX_GROW = 10
PROTECTION_LIMIT = 50  # تا ۵۰ سانت منفی نمی‌شوند
DAILY_BONUS_MIN = 1
DAILY_BONUS_MAX = 5
PVP_CODE_LENGTH = 6

# ─── اتصال دیتابیس ───
def get_db():
  conn = sqlite3.connect(DB_PATH, check_same_thread=False)
  conn.row_factory = sqlite3.Row
  return conn

def init_db():
  conn = get_db()
  c = conn.cursor()

  c.executescript("""
    CREATE TABLE IF NOT EXISTS users (
      user_id TEXT PRIMARY KEY,
      name TEXT,
      username TEXT
    );

    CREATE TABLE IF NOT EXISTS group_members (
      user_id TEXT,
      group_id TEXT,
      length INTEGER DEFAULT 0,
      last_grow_date TEXT,
      total_grows INTEGER DEFAULT 0,
      coin INTEGER DEFAULT 0,
      PRIMARY KEY (user_id, group_id)
    );

    CREATE TABLE IF NOT EXISTS pvp_challenges (
      code TEXT PRIMARY KEY,
      challenger_id TEXT,
      group_id TEXT,
      amount INTEGER,
      created_at TEXT
    );

    CREATE TABLE IF NOT EXISTS daily_winners (
      group_id TEXT,
      winner_id TEXT,
      win_date TEXT,
      bonus INTEGER,
      PRIMARY KEY (group_id, win_date)
    );

    CREATE TABLE IF NOT EXISTS transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      from_user TEXT,
      to_user TEXT,
      amount INTEGER,
      group_id TEXT,
      type TEXT,
      created_at TEXT
    );

    CREATE TABLE IF NOT EXISTS admin_sessions (
      user_id TEXT PRIMARY KEY,
      is_admin INTEGER DEFAULT 0
    );
  """)

  conn.commit()
  conn.close()

init_db()

# ─── توابع کمکی ───
def today_str():
  return datetime.date.today().isoformat()

def now_str():
  return datetime.datetime.now().isoformat()

def generate_pvp_code():
  return ''.join(random.choices(string.ascii_uppercase + string.digits, k=PVP_CODE_LENGTH))

def get_user_name(bot, user_id):
  try:
    return bot.get_name(user_id) or user_id
  except Exception:
    return user_id

def format_length(length):
  if length >= 0:
    return f"📏 {length} سانت"
  return f"📏 {length} سانت"

# ─── عملیات دیتابیس ───
def db_get_member(user_id, group_id):
  conn = get_db()
  c = conn.cursor()
  c.execute("SELECT * FROM group_members WHERE user_id=? AND group_id=?", (user_id, group_id))
  row = c.fetchone()
  conn.close()
  return row

def db_ensure_member(user_id, group_id, name=""):
  conn = get_db()
  c = conn.cursor()
  c.execute(
    "INSERT OR IGNORE INTO group_members (user_id, group_id, length, last_grow_date, total_grows, coin) VALUES (?, ?, 0, '', 0, 0)",
    (user_id, group_id)
  )
  conn.commit()
  conn.close()

def db_update_length(user_id, group_id, new_length):
  conn = get_db()
  c = conn.cursor()
  c.execute("UPDATE group_members SET length=? WHERE user_id=? AND group_id=?", (new_length, user_id, group_id))
  conn.commit()
  conn.close()

def db_set_last_grow(user_id, group_id, date_str, total_grows):
  conn = get_db()
  c = conn.cursor()
  c.execute(
    "UPDATE group_members SET last_grow_date=?, total_grows=? WHERE user_id=? AND group_id=?",
    (date_str, total_grows, user_id, group_id)
  )
  conn.commit()
  conn.close()

def db_add_transaction(from_user, to_user, amount, group_id, t_type):
  conn = get_db()
  c = conn.cursor()
  c.execute(
    "INSERT INTO transactions (from_user, to_user, amount, group_id, type, created_at) VALUES (?, ?, ?, ?, ?, ?)",
    (from_user, to_user, amount, group_id, t_type, now_str())
  )
  conn.commit()
  conn.close()

def db_get_top(group_id, limit=10):
  conn = get_db()
  c = conn.cursor()
  c.execute(
    "SELECT user_id, length, total_grows FROM group_members WHERE group_id=? ORDER BY length DESC LIMIT ?",
    (group_id, limit)
  )
  rows = c.fetchall()
  conn.close()
  return rows

def db_get_challenge(code):
  conn = get_db()
  c = conn.cursor()
  c.execute("SELECT * FROM pvp_challenges WHERE code=?", (code,))
  row = c.fetchone()
  conn.close()
  return row

def db_create_challenge(code, challenger_id, group_id, amount):
  conn = get_db()
  c = conn.cursor()
  c.execute(
    "INSERT INTO pvp_challenges (code, challenger_id, group_id, amount, created_at) VALUES (?, ?, ?, ?, ?)",
    (code, challenger_id, group_id, amount, now_str())
  )
  conn.commit()
  conn.close()

def db_delete_challenge(code):
  conn = get_db()
  c = conn.cursor()
  c.execute("DELETE FROM pvp_challenges WHERE code=?", (code,))
  conn.commit()
  conn.close()

def db_get_daily_winner(group_id, date_str):
  conn = get_db()
  c = conn.cursor()
  c.execute("SELECT * FROM daily_winners WHERE group_id=? AND win_date=?", (group_id, date_str))
  row = c.fetchone()
  conn.close()
  return row

def db_set_daily_winner(group_id, winner_id, date_str, bonus):
  conn = get_db()
  c = conn.cursor()
  c.execute(
    "INSERT OR REPLACE INTO daily_winners (group_id, winner_id, win_date, bonus) VALUES (?, ?, ?, ?)",
    (group_id, winner_id, date_str, bonus)
  )
  conn.commit()
  conn.close()

def db_get_active_members(group_id, since_date):
  conn = get_db()
  c = conn.cursor()
  c.execute(
    "SELECT user_id FROM group_members WHERE group_id=? AND last_grow_date >= ?",
    (group_id, since_date)
  )
  rows = c.fetchall()
  conn.close()
  return [r["user_id"] for r in rows]

def db_ensure_user(user_id, name="", username=""):
  conn = get_db()
  c = conn.cursor()
  c.execute(
    "INSERT OR IGNORE INTO users (user_id, name, username) VALUES (?, ?, ?)",
    (user_id, name, username)
  )
  conn.commit()
  conn.close()

def db_set_admin(user_id, is_admin=1):
  conn = get_db()
  c = conn.cursor()
  c.execute(
    "INSERT OR REPLACE INTO admin_sessions (user_id, is_admin) VALUES (?, ?)",
    (user_id, is_admin)
  )
  conn.commit()
  conn.close()

def db_is_admin(user_id):
  conn = get_db()
  c = conn.cursor()
  c.execute("SELECT is_admin FROM admin_sessions WHERE user_id=?", (user_id,))
  row = c.fetchone()
  conn.close()
  return row is not None and row["is_admin"] == 1

def db_get_all_groups():
  conn = get_db()
  c = conn.cursor()
  c.execute("SELECT DISTINCT group_id FROM group_members")
  rows = c.fetchall()
  conn.close()
  return [r["group_id"] for r in rows]

def db_get_stats():
  conn = get_db()
  c = conn.cursor()
  c.execute("SELECT COUNT(DISTINCT user_id) as users FROM group_members")
  users = c.fetchone()["users"]
  c.execute("SELECT COUNT(DISTINCT group_id) as groups FROM group_members")
  groups = c.fetchone()["groups"]
  c.execute("SELECT COUNT(*) as pvps FROM transactions WHERE type='pvp'")
  pvps = c.fetchone()["pvps"]
  conn.close()
  return users, groups, pvps

# ─── راه‌اندازی ربات ───
TOKEN = os.environ.get("RUBIKA_BOT_TOKEN", "BEJEJG0OTQZXAPRNCGFABRQXAFOJHHQQXHPJZYVZDDBYSMNHQPWHVGILMWMQUJBC")
bot = Robot(token=TOKEN)

# ─── دستور /start ───
@bot.on_message(commands=["start"])
def cmd_start(bot, message):
  text = (
    "📏 به ربات خطکش خوش آمدید!\n\n"
    "این ربات یه بازی سرگرم‌کننده تو گروه‌هاست.\n"
    "هر روز می‌تونی خطکشت رو رشد بدی و با بقیه رقابت کنی!\n\n"
    "📚 برای راهنما: /help\n"
    "made by @hajibehnad"
  )
  message.reply(text)

# ─── دستور /help ───
@bot.on_message(commands=["help"])
def cmd_help(bot, message):
  text = (
    "📚 راهنمای کامل ربات اندازه‌گیری دود\n\n"
    "این ربات یه بازی سرگرم‌کننده تو گروه‌هاست. هر روز می‌تونی خطکشت رو رشد بدی و با بقیه رقابت کنی!\n\n"
    "🌟 دستورات اصلی:\n"
    "- /grow - رشد روزانه خطکش\n"
    "- /top - نمایش برترین‌های این گروه\n"
    "- /dod - انتخاب خطکش روز\n"
    "- /pvp <مقدار> - مبارزه با شرط‌بندی\n"
    "- /accept <کد> - قبول مبارزه\n"
    "- /stats - آمار شخصی در این گروه\n"
    "- /help - نمایش این راهنما\n"
    "- /groupid - نمایش آیدی گروه\n"
    "- /shop - فروشگاه سکه\n"
    "- /send <شناسه> <مقدار> - ارسال سانت به بازیکن\n"
    "- /transfer to <مقدار> <آیدی> - انتقال سانت بین گروه‌ها\n\n"
    "⚔️ نحوه مبارزه:\n"
    "۱. با دستور /pvp 5 یه مبارزه با شرط ۵ سانت شروع کن\n"
    "۲. یه کد مبارزه بهت داده میشه\n"
    "۳. دوستت با دستور /accept <کد> مبارزه رو قبول می‌کنه\n"
    "۴. برنده به‌صورت تصادفی انتخاب میشه و شرط جابجا میشه\n\n"
    "🏆 خطکش روز:\n"
    "هر روز یه نفر به‌صورت تصادفی به عنوان خطکش روز انتخاب میشه و ۱ تا ۵ سانت پاداش می‌گیره.\n"
    "فقط کسایی که تو یک هفته اخیر رشد کردن می‌تونن برنده بشن.\n\n"
    "📊 نکات مهم:\n"
    "- هر کاربر تو هر گروه یه خطکش جداگانه داره\n"
    "- روزی فقط یه بار می‌تونی رشد کنی\n"
    "- اگه تازه‌کاری، تا ۵۰ سانت منفی نمیشی\n"
    "- بعد از ۵۰ سانت، ممکنه بعضی روزها کوچک بشی\n\n"
    "made by @hajibehnad"
  )
  message.reply(text)

# ─── دستور /grow ───
@bot.on_message_group(commands=["grow"])
def cmd_grow(bot, message):
  user_id = message.sender_id
  group_id = message.chat_id
  try:
    user_name = bot.get_name(user_id) or ""
  except Exception:
    user_name = ""
  db_ensure_user(user_id, user_name)
  db_ensure_member(user_id, group_id)

  member = db_get_member(user_id, group_id)
  current_length = member["length"]
  last_grow = member["last_grow_date"]
  total_grows = member["total_grows"]

  if last_grow == today_str():
    message.reply("⏳ امروز قبلاً رشد کردی! فردا دوباره بیا. 🌱")
    return

  # محاسبه رشد
  if current_length >= 50:
    # بعد از ۵۰ سانت، ممکنه کوچک بشی
    growth = random.randint(-3, 10)
  else:
    growth = random.randint(DEFAULT_MIN_GROW, DEFAULT_MAX_GROW)

  new_length = current_length + growth

  # محافظت تازه‌کار
  if total_grows < 5 and new_length < -50:
    new_length = -50
    growth = new_length - current_length

  db_update_length(user_id, group_id, new_length)
  db_set_last_grow(user_id, group_id, today_str(), total_grows + 1)

  if growth > 0:
    msg = (
      f"🌱 رشد روزانه!\n\n"
      f"📏 امروز {growth} سانت رشد کردی!\n"
      f"📊 خطکش فعلی: {new_length} سانت\n"
      f"📈 تعداد رشدها: {total_grows + 1}\n\n"
      f"فردا دوباره بیا! 🚀"
    )
  elif growth < 0:
    msg = (
      f"😅 اوپس! امروز {abs(growth)} سانت کوچک شدی!\n\n"
      f"📏 خطکش فعلی: {new_length} سانت\n"
      f"📈 تعداد رشدها: {total_grows + 1}\n\n"
      f"ناراحت نباش، فردا دوباره رشد می‌کنی! 💪"
    )
  else:
    msg = (
      f"😐 امروز تغییری نکردی!\n\n"
      f"📏 خطکش فعلی: {new_length} سانت\n"
      f"فردا شانس دوباره می‌گیری! 🍀"
    )

  message.reply(msg)

# ─── دستور /stats ───
@bot.on_message_group(commands=["stats"])
def cmd_stats(bot, message):
  user_id = message.sender_id
  group_id = message.chat_id
  db_ensure_member(user_id, group_id)

  member = db_get_member(user_id, group_id)
  name = get_user_name(bot, user_id)

  text = (
    f"📊 آمار شخصی {name}:\n\n"
    f"📏 طول خطکش: {member['length']} سانت\n"
    f"📈 تعداد رشدها: {member['total_grows']}\n"
    f"🪙 سکه‌ها: {member['coin']}\n"
    f"📅 آخرین رشد: {member['last_grow_date'] or 'هرگز'}\n\n"
    f"ادامه بده! 💪"
  )
  message.reply(text)

# ─── دستور /top ───
@bot.on_message_group(commands=["top"])
def cmd_top(bot, message):
  group_id = message.chat_id
  rows = db_get_top(group_id, 10)

  if not rows:
    message.reply("📭 هنوز کسی تو این گروه بازی نکرده! با /grow شروع کن.")
    return

  lines = ["🏆 برترین‌های گروه:\n"]
  medals = ["🥇", "🥈", "🥉", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"]
  for i, row in enumerate(rows):
    name = get_user_name(bot, row["user_id"])
    medal = medals[i] if i < len(medals) else f"{i+1}."
    lines.append(f"{medal} {name} — {row['length']} سانت ({row['total_grows']} رشد)")

  message.reply("\n".join(lines))

# ─── دستور /groupid ───
@bot.on_message_group(commands=["groupid"])
def cmd_groupid(bot, message):
  message.reply(f"🆔 آیدی این گروه:\n<code>{message.chat_id}</code>")

# ─── دستور /pvp ───
@bot.on_message_group(commands=["pvp"])
def cmd_pvp(bot, message):
  user_id = message.sender_id
  group_id = message.chat_id
  args = message.args

  if not args:
    message.reply("❌ لطفاً مقدار شرط رو وارد کن.\nمثال: /pvp 5")
    return

  try:
    amount = int(args[0])
  except ValueError:
    message.reply("❌ مقدار شرط باید عدد باشه.")
    return

  if amount <= 0:
    message.reply("❌ مقدار شرط باید بزرگتر از صفر باشه.")
    return

  db_ensure_member(user_id, group_id)
  member = db_get_member(user_id, group_id)

  if member["length"] < amount:
    message.reply(f"❌ سانت کافی نداری!\n📏 سانت فعلی: {member['length']}")
    return

  code = generate_pvp_code()
  db_create_challenge(code, user_id, group_id, amount)

  text = (
    f"⚔️ مبارزه جدید!\n\n"
    f"👤 چالش‌دهنده: {get_user_name(bot, user_id)}\n"
    f"💰 شرط: {amount} سانت\n"
    f"🔑 کد مبارزه: <code>{code}</code>\n\n"
    f"برای قبول مبارزه دستور بزن:\n"
    f"/accept {code}"
  )
  message.reply(text)

# ─── دستور /accept ───
@bot.on_message_group(commands=["accept"])
def cmd_accept(bot, message):
  user_id = message.sender_id
  group_id = message.chat_id
  args = message.args

  if not args:
    message.reply("❌ لطفاً کد مبارزه رو وارد کن.\nمثال: /accept ABC123")
    return

  code = args[0].upper().strip()
  challenge = db_get_challenge(code)

  if not challenge:
    message.reply("❌ کد مبارزه پیدا نشد!")
    return

  if challenge["group_id"] != group_id:
    message.reply("❌ این کد مبارزه متعلق به گروه دیگه‌ایه!")
    return

  challenger_id = challenge["challenger_id"]
  amount = challenge["amount"]

  if user_id == challenger_id:
    message.reply("❌ نمی‌تونی با خودت مبارزه کنی!")
    return

  db_ensure_member(user_id, group_id)
  opponent = db_get_member(user_id, group_id)
  challenger = db_get_member(challenger_id, group_id)

  if opponent["length"] < amount:
    message.reply(f"❌ سانت کافی نداری!\n📏 سانت فعلی: {opponent['length']}")
    return

  # تعیین برنده تصادفی
  winner_id = random.choice([challenger_id, user_id])
  loser_id = challenger_id if winner_id == user_id else user_id

  # جابجایی شرط
  new_winner_length = db_get_member(winner_id, group_id)["length"] + amount
  new_loser_length = db_get_member(loser_id, group_id)["length"] - amount

  db_update_length(winner_id, group_id, new_winner_length)
  db_update_length(loser_id, group_id, new_loser_length)
  db_add_transaction(loser_id, winner_id, amount, group_id, "pvp")
  db_delete_challenge(code)

  winner_name = get_user_name(bot, winner_id)
  loser_name = get_user_name(bot, loser_id)
  challenger_name = get_user_name(bot, challenger_id)
  opponent_name = get_user_name(bot, user_id)

  text = (
    f"⚔️ نتیجه مبارزه!\n\n"
    f"👤 {challenger_name} vs {opponent_name}\n"
    f"💰 شرط: {amount} سانت\n\n"
    f"🏆 برنده: {winner_name}\n"
    f"📏 سانت برنده: {new_winner_length} (+{amount})\n"
    f"📏 سانت بازنده: {new_loser_length} (-{amount})\n\n"
    f"تبریک! 🎉"
  )
  message.reply(text)

# ─── دستور /dod ───
@bot.on_message_group(commands=["dod"])
def cmd_dod(bot, message):
  group_id = message.chat_id
  today = today_str()

  # بررسی آیا امروز قبلاً انتخاب شده
  existing = db_get_daily_winner(group_id, today)
  if existing:
    winner_name = get_user_name(bot, existing["winner_id"])
    message.reply(
      f"🏆 خطکش امروز قبلاً انتخاب شده!\n\n"
      f"👤 برنده: {winner_name}\n"
      f"🎁 پاداش: {existing['bonus']} سانت\n\n"
      f"فردا دوباره امتحان کن! 🍀"
    )
    return

  # پیدا کردن کاربران فعال (یک هفته اخیر)
  week_ago = (datetime.date.today() - datetime.timedelta(days=7)).isoformat()
  active_users = db_get_active_members(group_id, week_ago)

  if not active_users:
    message.reply("😕 هنوز کسی تو یک هفته اخیر رشد نکرده! با /grow شروع کن.")
    return

  winner_id = random.choice(active_users)
  bonus = random.randint(DAILY_BONUS_MIN, DAILY_BONUS_MAX)

  db_ensure_member(winner_id, group_id)
  member = db_get_member(winner_id, group_id)
  new_length = member["length"] + bonus
  db_update_length(winner_id, group_id, new_length)
  db_set_daily_winner(group_id, winner_id, today, bonus)

  winner_name = get_user_name(bot, winner_id)
  message.reply(
    f"🏆 خطکش روز انتخاب شد!\n\n"
    f"👤 برنده: {winner_name}\n"
    f"🎁 پاداش: {bonus} سانت\n"
    f"📏 سانت فعلی: {new_length} سانت\n\n"
    f"تبریک! 🎉🎉"
  )

# ─── دستور /send ───
@bot.on_message_group(commands=["send"])
def cmd_send(bot, message):
  user_id = message.sender_id
  group_id = message.chat_id
  args = message.args

  if len(args) < 2:
    message.reply("❌ لطفاً شناسه و مقدار رو وارد کن.\nمثال: /send g0abc123 10")
    return

  target_id = args[0]
  try:
    amount = int(args[1])
  except ValueError:
    message.reply("❌ مقدار باید عدد باشه.")
    return

  if amount <= 0:
    message.reply("❌ مقدار باید بزرگتر از صفر باشه.")
    return

  db_ensure_member(user_id, group_id)
  sender = db_get_member(user_id, group_id)

  if sender["length"] < amount:
    message.reply(f"❌ سانت کافی نداری!\n📏 سانت فعلی: {sender['length']}")
    return

  db_ensure_member(target_id, group_id)
  target = db_get_member(target_id, group_id)

  db_update_length(user_id, group_id, sender["length"] - amount)
  db_update_length(target_id, group_id, target["length"] + amount)
  db_add_transaction(user_id, target_id, amount, group_id, "send")

  target_name = get_user_name(bot, target_id)
  sender_name = get_user_name(bot, user_id)

  message.reply(
    f"📤 ارسال سانت\n\n"
    f"👤 فرستنده: {sender_name}\n"
    f"👤 گیرنده: {target_name}\n"
    f"💰 مقدار: {amount} سانت\n\n"
    f"✅ با موفقیت ارسال شد!"
  )

# ─── دستور /transfer ───
@bot.on_message_group(commands=["transfer"])
def cmd_transfer(bot, message):
  user_id = message.sender_id
  source_group = message.chat_id
  args = message.args

  if len(args) < 3 or args[0].lower() != "to":
    message.reply("❌ فرمت اشتباه!\nمثال: /transfer to 10 g0targetgroup")
    return

  try:
    amount = int(args[1])
  except ValueError:
    message.reply("❌ مقدار باید عدد باشه.")
    return

  target_group = args[2]

  if amount <= 0:
    message.reply("❌ مقدار باید بزرگتر از صفر باشه.")
    return

  db_ensure_member(user_id, source_group)
  source = db_get_member(user_id, source_group)

  if source["length"] < amount:
    message.reply(f"❌ سانت کافی نداری!\n📏 سانت فعلی: {source['length']}")
    return

  db_ensure_member(user_id, target_group)
  target = db_get_member(user_id, target_group)

  db_update_length(user_id, source_group, source["length"] - amount)
  db_update_length(user_id, target_group, target["length"] + amount)
  db_add_transaction(user_id, user_id, amount, source_group, "transfer")

  message.reply(
    f"🔄 انتقال سانت بین گروه‌ها\n\n"
    f"💰 مقدار: {amount} سانت\n"
    f"📤 از گروه: {source_group}\n"
    f"📥 به گروه: {target_group}\n\n"
    f"✅ با موفقیت منتقل شد!"
  )

# ─── دستور /shop ───
@bot.on_message_group(commands=["shop"])
def cmd_shop(bot, message):
  text = (
    "🛒 فروشگاه خطکش\n\n"
    "۱. 🛡️ محافظت از کوچک‌شدن - ۲۰ سانت\n"
    "   (برای ۳ روز رشد منفی نمی‌گیری)\n\n"
    "۲. 🍀 شانس دوبرابر - ۱۵ سانت\n"
    "   (رشد بعدی ۲ برابر می‌شه)\n\n"
    "۳. 🎁 جعبه شانسی - ۱۰ سانت\n"
    "   (۱ تا ۲۰ سانت تصادفی)\n\n"
    "۴. 💰 ۵۰ سکه - ۲۵ سانت\n"
    "   (برای خریدهای آینده)\n\n"
    "⚠️ این نسخه نمایشیه. برای خرید با ادمین تماس بگیر."
  )
  message.reply(text)

# ─── دستور /buy (فروشگاه) ───
@bot.on_message_group(commands=["buy"])
def cmd_buy(bot, message):
  user_id = message.sender_id
  group_id = message.chat_id
  args = message.args

  if not args:
    message.reply("❌ لطفاً شماره آیتم رو وارد کن.\nمثال: /buy 1")
    return

  item = args[0]
  db_ensure_member(user_id, group_id)
  member = db_get_member(user_id, group_id)
  current = member["length"]

  items = {
    "1": ("🛡️ محافظت از کوچک‌شدن", 20, "برای ۳ روز محافظت فعال شد! 🛡️"),
    "2": ("🍀 شانس دوبرابر", 15, "شانس دوبرابر برای رشد بعدی! 🍀"),
    "3": ("🎁 جعبه شانسی", 10, None),  # تصادفی
    "4": ("💰 ۵۰ سکه", 25, "۵۰ سکه به حسابت اضافه شد! 💰"),
  }

  if item not in items:
    message.reply("❌ آیتم نامعتبر! آیتم‌های موجود: ۱ تا ۴")
    return

  name, price, msg = items[item]

  if current < price:
    message.reply(f"❌ سانت کافی نداری!\n📏 سانت فعلی: {current}\n💰 قیمت: {price}")
    return

  db_update_length(user_id, group_id, current - price)

  if item == "3":
    bonus = random.randint(1, 20)
    new_len = current - price + bonus
    db_update_length(user_id, group_id, new_len)
    message.reply(
      f"🎁 جعبه شانسی باز شد!\n\n"
      f"💰 هزینه: {price} سانت\n"
      f"🎁 جایزه: {bonus} سانت\n"
      f"📏 سانت فعلی: {new_len} سانت\n\n"
      f"تبریک! 🎉"
    )
    return

  message.reply(f"✅ خرید موفق!\n\n🛒 {name}\n💰 هزینه: {price} سانت\n\n{msg}")

# ═══════════════════════════════════════════
# پنل مدیریت (با رمز مخفی)
# ═══════════════════════════════════════════

# ═══════════════════════════════════════════
# پنل مدیریت (مخفی — بدون دستور /panel و /admin)
# ═══════════════════════════════════════════

def _open_admin_panel(bot, message):
  """باز کردن پنل مدیریت (مخفی)"""
  user_id = message.sender_id
  args = message.args

  if not args:
    return

  password = args[0]
  if password != ADMIN_SECRET:
    return

  db_set_admin(user_id, 1)

  keypad = (
    ChatKeypadBuilder()
    .row(
      ChatKeypadBuilder().button(id="admin_stats", text="📊 آمار کلی"),
      ChatKeypadBuilder().button(id="admin_broadcast", text="📢 ارسال همگانی"),
    )
    .row(
      ChatKeypadBuilder().button(id="admin_groups", text="👥 گروه‌ها"),
      ChatKeypadBuilder().button(id="admin_reset", text="🔄 ریست کاربر"),
    )
    .row(
      ChatKeypadBuilder().button(id="admin_exit", text="❌ خروج"),
    )
    .build()
  )

  message.reply("🔐 پنل مدیریت باز شد!\n\nیک گزینه انتخاب کن:", chat_keypad=keypad)

@bot.on_callback("admin_stats")
def cb_admin_stats(bot, message):
  if not db_is_admin(message.sender_id):
    message.reply("❌ دسترسی نداری!")
    return
  users, groups, pvps = db_get_stats()
  text = (
    f"📊 آمار کلی ربات:\n\n"
    f"👤 تعداد کاربران: {users}\n"
    f"👥 تعداد گروه‌ها: {groups}\n"
    f"⚔️ تعداد مبارزات: {pvps}\n\n"
    f"📅 تاریخ: {today_str()}"
  )
  message.reply(text)

@bot.on_callback("admin_groups")
def cb_admin_groups(bot, message):
  if not db_is_admin(message.sender_id):
    message.reply("❌ دسترسی نداری!")
    return
  groups = db_get_all_groups()
  if not groups:
    message.reply("📭 هیچ گروهی یافت نشد.")
    return
  text = "👥 لیست گروه‌ها:\n\n" + "\n".join([f"• {g}" for g in groups[:20]])
  message.reply(text)

@bot.on_callback("admin_broadcast")
def cb_admin_broadcast(bot, message):
  if not db_is_admin(message.sender_id):
    message.reply("❌ دسترسی نداری!")
    return
  message.reply(
    "📢 ارسال همگانی:\n\n"
    "برای ارسال پیام به همه کاربران، دستور زیر رو بزن:\n"
    "/broadcast <متن پیام>\n\n"
    "مثال: /broadcast سلام به همه!"
  )

@bot.on_message_private(commands=["broadcast"])
def cmd_broadcast(bot, message):
  if not db_is_admin(message.sender_id):
    return
  args = message.args
  if not args:
    message.reply("❌ لطفاً متن پیام رو وارد کن.")
    return

  text = " ".join(args)
  conn = get_db()
  c = conn.cursor()
  c.execute("SELECT DISTINCT user_id FROM group_members")
  rows = c.fetchall()
  conn.close()

  sent = 0
  for row in rows:
    try:
      bot.send_message(row["user_id"], f"📢 پیام از ادمین:\n\n{text}")
      sent += 1
    except Exception:
      pass

  message.reply(f"✅ پیام به {sent} کاربر ارسال شد.")

@bot.on_callback("admin_reset")
def cb_admin_reset(bot, message):
  if not db_is_admin(message.sender_id):
    message.reply("❌ دسترسی نداری!")
    return
  message.reply(
    "🔄 ریست کاربر:\n\n"
    "برای ریست کردن آمار یک کاربر، دستور زیر رو بزن:\n"
    "/resetuser <user_id>\n\n"
    "مثال: /resetuser g0abc123"
  )

@bot.on_message_private(commands=["resetuser"])
def cmd_resetuser(bot, message):
  if not db_is_admin(message.sender_id):
    return
  args = message.args
  if not args:
    message.reply("❌ لطفاً آیدی کاربر رو وارد کن.")
    return

  target_id = args[0]
  conn = get_db()
  c = conn.cursor()
  c.execute("DELETE FROM group_members WHERE user_id=?", (target_id,))
  c.execute("DELETE FROM pvp_challenges WHERE challenger_id=?", (target_id,))
  conn.commit()
  conn.close()

  message.reply(f"✅ آمار کاربر {target_id} ریست شد.")

@bot.on_callback("admin_exit")
def cb_admin_exit(bot, message):
  db_set_admin(message.sender_id, 0)
  message.reply("🔒 از پنل مدیریت خارج شدی.")

# ═══════════════════════════════════════════
# هندلر رمز مخفی در چت خصوصی
# ═══════════════════════════════════════════

@bot.on_message_private()
def handle_private_text(bot, message):
  text = message.text or ""
  if text.strip() == ADMIN_SECRET:
    message.args = [ADMIN_SECRET]
    _open_admin_panel(bot, message)

# ═══════════════════════════════════════════
# اجرا
# ═══════════════════════════════════════════

if __name__ == "__main__":
  print("🤖 ربات خطکش در حال اجراست...")
  print("made by @hajibehnad")
  bot.run()

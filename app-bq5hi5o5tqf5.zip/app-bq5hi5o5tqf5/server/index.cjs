#!/usr/bin/env node
// سرور مدیریت ربات — Express + child_process
'use strict';

const express = require('express');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3001;
const ADMIN_PASSWORD = 'githd';
const BOT_PATH = path.resolve(__dirname, '../tasks/bot_project/bot.py');
const BOT_DIR = path.resolve(__dirname, '../tasks/bot_project');
const DB_PATH = path.resolve(__dirname, '../tasks/bot_project/ruler_game.db');
const RUBKA_PATH = path.resolve(__dirname, '../tasks/rubka-main');

app.use(express.json());

// CORS
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

// ── احراز هویت ساده با header ──
const sessions = new Set();

function authMiddleware(req, res, next) {
  const token = req.headers['authorization'];
  if (token && sessions.has(token)) return next();
  return res.status(401).json({ ok: false, error: 'احراز هویت نشده' });
}

// ── وضعیت ربات ──
let botProcess = null;
let botStartTime = null;
let restartCount = 0;
let autoRestart = true;
let logs = [];
const MAX_LOGS = 1000;

function appendLog(line) {
  logs.push({ time: new Date().toISOString(), text: line });
  if (logs.length > MAX_LOGS) logs = logs.slice(-MAX_LOGS);
}

function spawnBot() {
  if (botProcess) return;

  const python = process.env.PYTHON_BIN || 'python3';
  botProcess = spawn(python, [BOT_PATH], {
    cwd: BOT_DIR,
    env: {
      ...process.env,
      PYTHONPATH: RUBKA_PATH,
      PYTHONUNBUFFERED: '1',
    },
  });

  botStartTime = new Date().toISOString();
  appendLog(`[پنل] ربات راه‌اندازی شد (PID: ${botProcess.pid})`);

  botProcess.stdout.on('data', (data) => {
    data.toString().split('\n').forEach((line) => {
      if (line.trim()) appendLog(line);
    });
  });

  botProcess.stderr.on('data', (data) => {
    data.toString().split('\n').forEach((line) => {
      if (line.trim()) appendLog(`[stderr] ${line}`);
    });
  });

  botProcess.on('close', (code) => {
    appendLog(`[پنل] ربات متوقف شد (کد: ${code})`);
    botProcess = null;
    botStartTime = null;

    if (autoRestart && code !== 0 && code !== null) {
      restartCount++;
      appendLog(`[پنل] راه‌اندازی مجدد خودکار (تعداد: ${restartCount})...`);
      setTimeout(spawnBot, 3000);
    }
  });

  botProcess.on('error', (err) => {
    appendLog(`[پنل] خطا: ${err.message}`);
    botProcess = null;
    botStartTime = null;
  });
}

function killBot(cb) {
  if (!botProcess) return cb && cb();
  autoRestart = false;
  botProcess.kill('SIGTERM');
  setTimeout(() => {
    if (botProcess) {
      botProcess.kill('SIGKILL');
      botProcess = null;
    }
    cb && cb();
    autoRestart = true;
  }, 2000);
}

// ── آمار SQLite ──
function getStats() {
  try {
    // استفاده از better-sqlite3 اگر موجود باشد
    let sqlite3;
    try { sqlite3 = require('better-sqlite3'); } catch(e) {
      try { sqlite3 = require('sqlite3'); } catch(e2) { return null; }
    }

    if (sqlite3.toString().includes('better-sqlite3') || typeof sqlite3 === 'function') {
      // better-sqlite3
      const db = sqlite3(DB_PATH, { readonly: true });
      const users = db.prepare("SELECT COUNT(DISTINCT user_id) as n FROM group_members").get().n;
      const groups = db.prepare("SELECT COUNT(DISTINCT group_id) as n FROM group_members").get().n;
      const pvps = db.prepare("SELECT COUNT(*) as n FROM transactions WHERE type='pvp'").get().n;
      db.close();
      return { users, groups, pvps };
    }
  } catch (e) {
    appendLog(`[پنل] خطا در خواندن آمار: ${e.message}`);
  }
  return null;
}

// ── مسیرها ──

// ورود
app.post('/api/login', (req, res) => {
  const { password } = req.body;
  if (password === ADMIN_PASSWORD) {
    const token = Math.random().toString(36).slice(2) + Date.now().toString(36);
    sessions.add(token);
    return res.json({ ok: true, token });
  }
  return res.status(401).json({ ok: false, error: 'رمز عبور اشتباه است' });
});

// خروج
app.post('/api/logout', authMiddleware, (req, res) => {
  sessions.delete(req.headers['authorization']);
  res.json({ ok: true });
});

// وضعیت ربات
app.get('/api/bot/status', authMiddleware, (req, res) => {
  res.json({
    ok: true,
    running: !!botProcess,
    pid: botProcess?.pid || null,
    startTime: botStartTime,
    restartCount,
    autoRestart,
  });
});

// شروع ربات
app.post('/api/bot/start', authMiddleware, (req, res) => {
  if (botProcess) return res.json({ ok: false, error: 'ربات در حال اجرا است' });
  if (!fs.existsSync(BOT_PATH)) return res.json({ ok: false, error: 'فایل ربات یافت نشد' });
  autoRestart = true;
  spawnBot();
  res.json({ ok: true });
});

// توقف ربات
app.post('/api/bot/stop', authMiddleware, (req, res) => {
  if (!botProcess) return res.json({ ok: false, error: 'ربات در حال اجرا نیست' });
  killBot(() => res.json({ ok: true }));
});

// راه‌اندازی مجدد
app.post('/api/bot/restart', authMiddleware, (req, res) => {
  killBot(() => {
    autoRestart = true;
    setTimeout(() => {
      spawnBot();
      res.json({ ok: true });
    }, 500);
  });
});

// لاگ‌ها (آخرین N خط)
app.get('/api/bot/logs', authMiddleware, (req, res) => {
  const since = parseInt(req.query.since || '0', 10);
  const result = logs.slice(since);
  res.json({ ok: true, logs: result, total: logs.length });
});

// پاک کردن لاگ‌ها
app.post('/api/bot/logs/clear', authMiddleware, (req, res) => {
  logs = [];
  res.json({ ok: true });
});

// آمار کلی
app.get('/api/stats', authMiddleware, (req, res) => {
  const stats = getStats();
  if (!stats) {
    return res.json({ ok: true, users: 0, groups: 0, pvps: 0, note: 'بدون اتصال به دیتابیس' });
  }
  res.json({ ok: true, ...stats });
});

// ارسال پیام همگانی
app.post('/api/broadcast', authMiddleware, async (req, res) => {
  const { message } = req.body;
  if (!message || !message.trim()) {
    return res.status(400).json({ ok: false, error: 'متن پیام خالی است' });
  }

  let users = [];
  try {
    let sqlite3;
    try { sqlite3 = require('better-sqlite3'); } catch(e) {
      try { sqlite3 = require('sqlite3'); } catch(e2) {}
    }
    if (sqlite3) {
      const db = sqlite3(DB_PATH, { readonly: true });
      users = db.prepare("SELECT DISTINCT user_id FROM group_members").all().map(r => r.user_id);
      db.close();
    }
  } catch (e) {
    return res.json({ ok: false, error: `خطا در خواندن کاربران: ${e.message}` });
  }

  const TOKEN = process.env.RUBIKA_BOT_TOKEN || 'BEJEJG0OTQZXAPRNCGFABRQXAFOJHHQQXHPJZYVZDDBYSMNHQPWHVGILMWMQUJBC';
  let sent = 0, failed = 0;

  for (const userId of users) {
    try {
      const r = await fetch(`https://botapi.rubika.ir/v3/${TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ chat_id: userId, text: `📢 پیام از ادمین:\n\n${message}` }),
      });
      const d = await r.json();
      if (d.status === 'OK') sent++; else failed++;
    } catch (e) {
      failed++;
    }
  }

  res.json({ ok: true, sent, failed, total: users.length });
});

// سرو فایل‌های static (پس از build)
const distPath = path.resolve(__dirname, '../dist');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get('*', (req, res) => res.sendFile(path.join(distPath, 'index.html')));
}

app.listen(PORT, () => {
  console.log(`🖥️  سرور مدیریت ربات روی پورت ${PORT} در حال اجراست`);
  console.log(`🔗 آدرس: http://localhost:${PORT}`);
});

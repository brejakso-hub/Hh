// کارت آمار کلی ربات
import { Users, LayoutGrid, Swords, Loader2, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { BotStats } from '@/types/bot';

interface Props {
  stats: BotStats | null;
  loading: boolean;
  onRefresh: () => void;
}

export default function StatsCard({ stats, loading, onRefresh }: Props) {
  const items = [
    { label: 'کاربران', value: stats?.users ?? 0, icon: Users, color: 'text-chart-2' },
    { label: 'گروه‌ها', value: stats?.groups ?? 0, icon: LayoutGrid, color: 'text-chart-3' },
    { label: 'مبارزات', value: stats?.pvps ?? 0, icon: Swords, color: 'text-chart-4' },
  ];

  return (
    <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-base font-semibold text-foreground text-balance">آمار کلی</h2>
        <Button
          variant="secondary"
          size="sm"
          onClick={onRefresh}
          disabled={loading}
          className="h-8 text-xs gap-1"
        >
          {loading ? (
            <Loader2 className="w-3 h-3 animate-spin" />
          ) : (
            <RefreshCw className="w-3 h-3" />
          )}
          بروزرسانی
        </Button>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {items.map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="bg-muted rounded-xl p-4 flex flex-col items-center gap-2">
            <Icon className={`w-5 h-5 ${color}`} />
            <p className="text-2xl font-bold text-foreground">
              {loading ? <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /> : value.toLocaleString('fa-IR')}
            </p>
            <p className="text-xs text-muted-foreground">{label}</p>
          </div>
        ))}
      </div>

      {stats?.note && (
        <p className="text-xs text-muted-foreground mt-3 text-center text-pretty">{stats.note}</p>
      )}
    </div>
  );
}

// کارت وضعیت ربات
import { formatDistanceToNow } from 'date-fns';
import { Bot, RotateCcw } from 'lucide-react';
import type { BotStatus } from '@/types/bot';

interface Props {
  status: BotStatus | null;
}

export default function StatusCard({ status }: Props) {
  const running = status?.running ?? false;

  return (
    <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${running ? 'bg-primary/10' : 'bg-muted'}`}>
            <Bot className={`w-5 h-5 ${running ? 'text-primary' : 'text-muted-foreground'}`} />
          </div>
          <div>
            <h2 className="text-base font-semibold text-foreground text-balance">وضعیت ربات</h2>
            <p className="text-xs text-muted-foreground mt-0.5">ربات خطکش روبیکا</p>
          </div>
        </div>

        {/* نشانگر وضعیت */}
        <div className="flex items-center gap-2">
          <span className={`text-sm font-medium ${running ? 'text-primary' : 'text-muted-foreground'}`}>
            {running ? 'در حال اجرا' : 'متوقف'}
          </span>
          <div
            className={`w-3 h-3 rounded-full ${running ? 'bg-primary status-pulse' : 'bg-muted-foreground/50'}`}
          />
        </div>
      </div>

      {/* جزئیات */}
      <div className="grid grid-cols-3 gap-3 mt-5">
        <div className="bg-muted rounded-lg p-3 text-center">
          <p className="text-xs text-muted-foreground mb-1">PID</p>
          <p className="text-sm font-semibold text-foreground">
            {status?.pid ?? '—'}
          </p>
        </div>
        <div className="bg-muted rounded-lg p-3 text-center">
          <p className="text-xs text-muted-foreground mb-1">شروع</p>
          <p className="text-sm font-semibold text-foreground">
            {status?.startTime
              ? formatDistanceToNow(new Date(status.startTime), { addSuffix: false })
                  .replace('about', '~')
              : '—'}
          </p>
        </div>
        <div className="bg-muted rounded-lg p-3 text-center">
          <div className="flex items-center justify-center gap-1 mb-1">
            <RotateCcw className="w-3 h-3 text-muted-foreground" />
            <p className="text-xs text-muted-foreground">ری‌استارت</p>
          </div>
          <p className="text-sm font-semibold text-foreground">
            {status?.restartCount ?? 0}
          </p>
        </div>
      </div>
    </div>
  );
}

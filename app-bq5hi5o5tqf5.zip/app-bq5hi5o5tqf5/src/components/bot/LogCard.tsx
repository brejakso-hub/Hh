// کارت لاگ زنده ربات
import { useEffect, useRef, useState } from 'react';
import { Terminal, Trash2, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { getLogs, clearLogs } from '@/services/botApi';
import type { LogEntry } from '@/types/bot';
import { toast } from 'sonner';

interface Props {
  running: boolean;
}

export default function LogCard({ running }: Props) {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [sinceIdx, setSinceIdx] = useState(0);
  const [clearing, setClearing] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // دریافت لاگ‌های جدید
  async function fetchLogs() {
    try {
      const res = await getLogs(sinceIdx);
      if (res.logs.length > 0) {
        setLogs((prev) => [...prev, ...res.logs].slice(-1000));
        setSinceIdx(res.total);
      }
    } catch {
      // بی‌صدا
    }
  }

  useEffect(() => {
    fetchLogs();
    intervalRef.current = setInterval(fetchLogs, 1500);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sinceIdx, running]);

  // اسکرول خودکار به پایین
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  async function handleClear() {
    setClearing(true);
    try {
      await clearLogs();
      setLogs([]);
      setSinceIdx(0);
      toast.success('لاگ‌ها پاک شدند');
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setClearing(false);
    }
  }

  function formatTime(iso: string) {
    return new Date(iso).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }

  function logColor(text: string) {
    if (text.includes('[stderr]') || text.includes('Error') || text.includes('خطا')) return 'text-destructive';
    if (text.includes('[پنل]')) return 'text-primary';
    if (text.includes('✅') || text.includes('موفق')) return 'text-chart-1';
    return 'text-foreground/80';
  }

  return (
    <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
      {/* هدر */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-primary" />
          <h2 className="text-base font-semibold text-foreground text-balance">لاگ زنده</h2>
          {running && (
            <span className="flex items-center gap-1 text-xs text-primary">
              <Loader2 className="w-3 h-3 animate-spin" />
              زنده
            </span>
          )}
        </div>
        <Button
          variant="secondary"
          size="sm"
          onClick={handleClear}
          disabled={clearing || logs.length === 0}
          className="h-8 text-xs gap-1"
        >
          {clearing ? <Loader2 className="w-3 h-3 animate-spin" /> : <Trash2 className="w-3 h-3" />}
          پاک کردن
        </Button>
      </div>

      {/* ترمینال */}
      <div className="bg-[hsl(222,18%,8%)] rounded-lg border border-border h-80 overflow-y-auto p-3">
        {logs.length === 0 ? (
          <p className="text-muted-foreground text-xs font-mono text-center mt-8">
            {running ? 'منتظر لاگ...' : 'ربات متوقف است. برای مشاهده لاگ، ربات را شروع کنید.'}
          </p>
        ) : (
          logs.map((log, i) => (
            <div key={i} className="flex gap-2 text-xs font-mono leading-5 min-w-0">
              <span className="text-muted-foreground shrink-0 select-none">{formatTime(log.time)}</span>
              <span className={`break-words min-w-0 ${logColor(log.text)}`}>{log.text}</span>
            </div>
          ))
        )}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}

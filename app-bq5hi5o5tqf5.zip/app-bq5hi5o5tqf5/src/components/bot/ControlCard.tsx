// کارت کنترل ربات
import { Play, Square, RotateCcw, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { BotStatus } from '@/types/bot';

interface Props {
  status: BotStatus | null;
  onStart: () => Promise<void>;
  onStop: () => Promise<void>;
  onRestart: () => Promise<void>;
  loading: boolean;
}

export default function ControlCard({ status, onStart, onStop, onRestart, loading }: Props) {
  const running = status?.running ?? false;

  return (
    <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
      <h2 className="text-base font-semibold text-foreground mb-4 text-balance">کنترل ربات</h2>

      <div className="flex flex-col md:flex-row gap-3">
        {/* دکمه شروع */}
        <Button
          onClick={onStart}
          disabled={running || loading}
          className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 font-semibold h-10 disabled:opacity-40"
        >
          {loading && !running ? (
            <Loader2 className="w-4 h-4 animate-spin ml-2" />
          ) : (
            <Play className="w-4 h-4 ml-2" />
          )}
          شروع
        </Button>

        {/* دکمه توقف */}
        <Button
          onClick={onStop}
          disabled={!running || loading}
          className="flex-1 bg-destructive text-destructive-foreground hover:bg-destructive/90 font-semibold h-10 disabled:opacity-40"
        >
          {loading && running ? (
            <Loader2 className="w-4 h-4 animate-spin ml-2" />
          ) : (
            <Square className="w-4 h-4 ml-2" />
          )}
          توقف
        </Button>

        {/* دکمه راه‌اندازی مجدد */}
        <Button
          onClick={onRestart}
          disabled={loading}
          variant="secondary"
          className="flex-1 font-semibold h-10 disabled:opacity-40"
        >
          {loading ? (
            <Loader2 className="w-4 h-4 animate-spin ml-2" />
          ) : (
            <RotateCcw className="w-4 h-4 ml-2" />
          )}
          ری‌استارت
        </Button>
      </div>

      {/* نمایش وضعیت auto-restart */}
      <div className="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
        <div className="w-2 h-2 rounded-full bg-primary status-pulse" />
        راه‌اندازی مجدد خودکار فعال است — در صورت قطع شدن ربات، ۳ ثانیه بعد دوباره راه‌اندازی می‌شود
      </div>
    </div>
  );
}

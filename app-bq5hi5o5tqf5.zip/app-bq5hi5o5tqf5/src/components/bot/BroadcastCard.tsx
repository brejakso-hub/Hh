// کارت ارسال پیام همگانی
import { useState } from 'react';
import { Send, Loader2, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { broadcast } from '@/services/botApi';
import { toast } from 'sonner';

export default function BroadcastCard() {
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ sent: number; failed: number; total: number } | null>(null);

  async function handleSend() {
    if (!message.trim()) {
      toast.error('لطفاً متن پیام را وارد کنید');
      return;
    }
    setLoading(true);
    setResult(null);
    try {
      const res = await broadcast(message);
      setResult(res);
      setMessage('');
      toast.success(`پیام به ${res.sent} کاربر ارسال شد`);
    } catch (e) {
      toast.error((e as Error).message || 'خطا در ارسال پیام');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
      <div className="flex items-center gap-2 mb-4">
        <Send className="w-4 h-4 text-primary" />
        <h2 className="text-base font-semibold text-foreground text-balance">ارسال پیام همگانی</h2>
      </div>

      <div className="flex flex-col gap-3">
        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-normal text-muted-foreground">متن پیام</label>
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="متن پیامی که برای همه کاربران ارسال می‌شود..."
            rows={3}
            className="bg-input border-border text-foreground placeholder:text-muted-foreground resize-none"
            disabled={loading}
          />
        </div>

        <Button
          onClick={handleSend}
          disabled={loading || !message.trim()}
          className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold h-10 w-full disabled:opacity-40"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin ml-2" />
              در حال ارسال...
            </>
          ) : (
            <>
              <Send className="w-4 h-4 ml-2" />
              ارسال به همه کاربران
            </>
          )}
        </Button>

        {/* نتیجه ارسال */}
        {result && (
          <div className="flex items-center gap-2 bg-primary/10 border border-primary/20 rounded-lg px-4 py-3 text-sm">
            <CheckCircle2 className="w-4 h-4 text-primary shrink-0" />
            <span className="text-foreground">
              <span className="font-semibold text-primary">{result.sent}</span> از{' '}
              <span className="font-semibold">{result.total}</span> کاربر دریافت کردند
              {result.failed > 0 && (
                <span className="text-destructive mr-2">({result.failed} ناموفق)</span>
              )}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}

// صفحه داشبورد اصلی پنل مدیریت
import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bot, LogOut, RefreshCw, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { getBotStatus, startBot, stopBot, restartBot, getStats, logout } from '@/services/botApi';
import type { BotStatus, BotStats } from '@/types/bot';
import StatusCard from '@/components/bot/StatusCard';
import ControlCard from '@/components/bot/ControlCard';
import LogCard from '@/components/bot/LogCard';
import StatsCard from '@/components/bot/StatsCard';
import BroadcastCard from '@/components/bot/BroadcastCard';
import { toast } from 'sonner';

export default function DashboardPage() {
  const navigate = useNavigate();
  const [status, setStatus] = useState<BotStatus | null>(null);
  const [stats, setStats] = useState<BotStats | null>(null);
  const [statusLoading, setStatusLoading] = useState(false);
  const [statsLoading, setStatsLoading] = useState(false);
  const [controlLoading, setControlLoading] = useState(false);

  // بررسی توکن
  useEffect(() => {
    const token = localStorage.getItem('bot_token');
    if (!token) navigate('/login', { replace: true });
  }, [navigate]);

  // دریافت وضعیت ربات
  const fetchStatus = useCallback(async () => {
    try {
      const s = await getBotStatus();
      setStatus(s);
    } catch (e) {
      const msg = (e as Error).message;
      if (msg.includes('احراز هویت') || msg.includes('401')) {
        localStorage.removeItem('bot_token');
        navigate('/login', { replace: true });
      }
    }
  }, [navigate]);

  // دریافت آمار
  const fetchStats = useCallback(async () => {
    setStatsLoading(true);
    try {
      const s = await getStats();
      setStats(s);
    } catch {
      // بی‌صدا
    } finally {
      setStatsLoading(false);
    }
  }, []);

  // polling هر ۳ ثانیه برای وضعیت
  useEffect(() => {
    fetchStatus();
    fetchStats();
    const statusInterval = setInterval(fetchStatus, 3000);
    const statsInterval = setInterval(fetchStats, 30000);
    return () => {
      clearInterval(statusInterval);
      clearInterval(statsInterval);
    };
  }, [fetchStatus, fetchStats]);

  async function handleStart() {
    setControlLoading(true);
    try {
      await startBot();
      await fetchStatus();
      toast.success('ربات شروع به کار کرد');
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setControlLoading(false);
    }
  }

  async function handleStop() {
    setControlLoading(true);
    try {
      await stopBot();
      await fetchStatus();
      toast.success('ربات متوقف شد');
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setControlLoading(false);
    }
  }

  async function handleRestart() {
    setControlLoading(true);
    try {
      await restartBot();
      await fetchStatus();
      toast.success('ربات دوباره راه‌اندازی شد');
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setControlLoading(false);
    }
  }

  async function handleLogout() {
    try {
      await logout();
    } catch {
      // بی‌صدا
    }
    localStorage.removeItem('bot_token');
    navigate('/login', { replace: true });
  }

  async function handleRefreshStatus() {
    setStatusLoading(true);
    await fetchStatus();
    setStatusLoading(false);
  }

  return (
    <div className="min-h-screen bg-background">
      {/* هدر */}
      <header className="sticky top-0 z-10 bg-card border-b border-border shadow-sm">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 text-primary" />
            </div>
            <h1 className="text-base font-bold text-foreground truncate text-balance">
              پنل مدیریت ربات
            </h1>
            {/* نشانگر وضعیت در هدر */}
            <div className={`w-2 h-2 rounded-full shrink-0 ${status?.running ? 'bg-primary status-pulse' : 'bg-muted-foreground/50'}`} />
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <Button
              variant="secondary"
              size="sm"
              onClick={handleRefreshStatus}
              disabled={statusLoading}
              className="h-8 text-xs hidden md:flex gap-1"
            >
              {statusLoading ? (
                <Loader2 className="w-3 h-3 animate-spin" />
              ) : (
                <RefreshCw className="w-3 h-3" />
              )}
              <span className="sr-only md:not-sr-only">بروزرسانی</span>
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={handleLogout}
              className="h-8 text-xs gap-1"
            >
              <LogOut className="w-3 h-3" />
              <span className="sr-only md:not-sr-only">خروج</span>
            </Button>
          </div>
        </div>
      </header>

      {/* محتوا */}
      <main className="max-w-5xl mx-auto px-4 py-6 flex flex-col gap-4">
        {/* وضعیت */}
        <StatusCard status={status} />

        {/* کنترل */}
        <ControlCard
          status={status}
          onStart={handleStart}
          onStop={handleStop}
          onRestart={handleRestart}
          loading={controlLoading}
        />

        {/* لاگ زنده */}
        <LogCard running={status?.running ?? false} />

        {/* آمار + ارسال پیام */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <StatsCard stats={stats} loading={statsLoading} onRefresh={fetchStats} />
          <BroadcastCard />
        </div>

        <p className="text-center text-xs text-muted-foreground pb-4">
          made by @hajibehnad
        </p>
      </main>
    </div>
  );
}

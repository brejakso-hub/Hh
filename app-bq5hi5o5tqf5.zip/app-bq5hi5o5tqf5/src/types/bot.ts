// انواع داده برای پنل مدیریت ربات

export interface BotStatus {
  running: boolean;
  pid: number | null;
  startTime: string | null;
  restartCount: number;
  autoRestart: boolean;
}

export interface LogEntry {
  time: string;
  text: string;
}

export interface BotStats {
  users: number;
  groups: number;
  pvps: number;
  note?: string;
}

export interface ApiResponse<T = unknown> {
  ok: boolean;
  error?: string;
  data?: T;
}

// سرویس ارتباط با سرور مدیریت ربات
import type { BotStatus, LogEntry, BotStats } from '@/types/bot';

const BASE = '/api';

function token() {
  return localStorage.getItem('bot_token') || '';
}

function headers() {
  return {
    'Content-Type': 'application/json',
    Authorization: token(),
  };
}

async function handle<T>(res: Response): Promise<T> {
  const data = await res.json();
  if (!data.ok) throw new Error(data.error || 'خطای ناشناخته');
  return data as T;
}

export async function login(password: string): Promise<string> {
  const res = await fetch(`${BASE}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password }),
  });
  const data = await res.json();
  if (!data.ok) throw new Error(data.error || 'رمز عبور اشتباه است');
  return data.token as string;
}

export async function logout(): Promise<void> {
  await fetch(`${BASE}/logout`, { method: 'POST', headers: headers() });
}

export async function getBotStatus(): Promise<BotStatus> {
  const res = await fetch(`${BASE}/bot/status`, { headers: headers() });
  const data = await handle<BotStatus & { ok: boolean }>(res);
  return data;
}

export async function startBot(): Promise<void> {
  const res = await fetch(`${BASE}/bot/start`, { method: 'POST', headers: headers() });
  await handle(res);
}

export async function stopBot(): Promise<void> {
  const res = await fetch(`${BASE}/bot/stop`, { method: 'POST', headers: headers() });
  await handle(res);
}

export async function restartBot(): Promise<void> {
  const res = await fetch(`${BASE}/bot/restart`, { method: 'POST', headers: headers() });
  await handle(res);
}

export async function getLogs(since: number = 0): Promise<{ logs: LogEntry[]; total: number }> {
  const res = await fetch(`${BASE}/bot/logs?since=${since}`, { headers: headers() });
  const data = await handle<{ logs: LogEntry[]; total: number; ok: boolean }>(res);
  return data;
}

export async function clearLogs(): Promise<void> {
  const res = await fetch(`${BASE}/bot/logs/clear`, { method: 'POST', headers: headers() });
  await handle(res);
}

export async function getStats(): Promise<BotStats> {
  const res = await fetch(`${BASE}/stats`, { headers: headers() });
  const data = await handle<BotStats & { ok: boolean }>(res);
  return data;
}

export async function broadcast(message: string): Promise<{ sent: number; failed: number; total: number }> {
  const res = await fetch(`${BASE}/broadcast`, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({ message }),
  });
  const data = await handle<{ sent: number; failed: number; total: number; ok: boolean }>(res);
  return data;
}
